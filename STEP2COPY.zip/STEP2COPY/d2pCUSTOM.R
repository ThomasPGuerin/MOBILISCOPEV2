# ================================================================================#
#                 Construction de la base de données des présences 
# 
#
# Description : 1. A partir de la BD_clean, création des tables de présence où
#               chaque ligne correspond à une présence géographique (secteur) et 
#               temporelle (une heure de la journée) et où chaque présence est 
#               caractérisée par le profil socio-démo de la personne enquêtée
#               2. création pour chaque ville d'une base "utile" pour p2m()
#               sans doublons, filtrée et au format long 
#       
#
# En entrée : BD_deplacement_clean et BD_personne_clean
# En sortie : BD_presence et BD_presence_utile_[ville]
#
# avril 2018 - AD
# rv en juillet 2020
# rv fev. 2021 pour inclure Canada
# rv juin 2021 intégration des villes sud-américaines
# oct. 2021 : correction des variables H4...H27 + calcul parallèle
# mars 2022 : réécriture complète de la fonction createPrez() 
#            (temps de computation 20 fois plus rapide)
#             et ajout de la fonction createPrezLong()
# sept 2022 : nom d'enquête en slug pour les sorties presence_utile  
#             + nouvelles règles doublons
# mai 2023 : ajout Idf 2020 dans createPrezLong()
#
# 
# 28 juin 2023 : dernière sortie des tables de présences (60 enquêtes)
# ================================================================================#


# Bibliothèque
library(tidyverse)
library(tidylog)
library(lubridate)

# ==== 1. BD_presence ====

# ~ Chargement des données de déplacement ---- 

# dossier d'entrée (hors git)
cheminIn <- "C:/Users/thoma/Desktop/TEST" # Maybe it needs to be in same dir as script

# Chargement de la BD_clean 
tripTable <- readRDS("TRIPTABLEV1.RDS")
indTable <- readRDS("PERSONTABLEV1.RDS")

####FIXING SOME TEMP STUFF
# handle missing values for MODE_ADH
tripTable$MODE_ADH[is.na(tripTable$MODE_ADH)] <- 0  # Default non-adherent

#Time Wrap-Around
# Adjust time wrap-around for H_START and H_END
tripTable <- tripTable %>%
  mutate(
    H_START = ifelse(H_START >= 24, H_START - 24, H_START),
    H_END = ifelse(H_END >= 24, H_END - 24, H_END),
    M_START = ifelse(H_START == 0 & M_START > 0, M_START - 60, M_START),
    M_END = ifelse(H_END == 0 & M_END > 0, M_END - 60, M_END)
  )

# adding pays and zonegeo columns
tripTable$PAYS <- 'UK'
tripTable$ZONEGEO <- 'Manchester'

indTable$PAYS <- 'UK'
indTable$ZONEGEO <- 'Manchester'


# ~ Création des présences ---- 

# Chargement de la fonction 
suppressWarnings(source("d2p_fct.R"))

# dossier de sortie (hors git)
cheminOut <- "C:/Users/thoma/Desktop/TEST/multitables/output.rds"
dir.create(cheminOut)



# ~~ sortir une table : ---- NOT WORKING
unique(tripTable$LIB_ED)
d2p(libED = "MANCHESTER, 2022", tripTable, indTable, cheminIn, cheminOut)



# ~~ OU sortir plusieurs tables : ----
## calcul parallèle 
require(foreach)
require(doParallel)

## choix des enquêtes
enq <- unique(tripTable$LIB_ED)#

###################################################################

#### PROBLEM WITH THIS PART OF THE SCRIPT EROROR IN VEC_INIT
# i think that it's likely a problem with the paths maybe witht he argumtes of the 
# function d2p not working properly - I need to check cheminIn and cheminOut
# The function does not work properly becuase aI do not have O_COG and D_COG cols
# I have to add these cols and encode each unique ward into a number

## packages utilisés  
myPck <- as.vector(.packages())

## setup parallel backend to use many processors
cores <- detectCores()
cl <- makeCluster(cores[1]-2) # ! not overload your server
registerDoParallel(cl)

T1<-Sys.time()
foreach(i = enq, .packages = myPck) %dopar% {
  
  d2p(libED = i, tripTable, indTable, cheminIn, cheminOut) #calling function - this bit messed up
  
}
## stop cluster
stopCluster(cl)

## process time = Tdiff
T2<-Sys.time()
(Tdiff= difftime(T2, T1)) 

# Time difference of 17.68813 mins pour 60 enquêtes





############ - Does not work becaues I have no O COG and no D COG

###################################################################
#NEW SCRIPT
# Set up parallel backend
cores <- detectCores()
cl <- makeCluster(cores[1] - 2)
registerDoParallel(cl)

# Measure start time
start_time <- Sys.time()

output_file <- "C:/Users/thoma/Desktop/TEST/output.rds"

# Parallel loop
results <- foreach(i = enq) %dopar% {
  tryCatch(
    {
      d2p(libED = i, tripTable, indTable, cheminIn, cheminOut)
      NULL
    },
    error = function(e) {
      message(paste("Error processing", i, ":", conditionMessage(e)))
      NULL
    }
  )
}

# Stop parallel cluster
stopCluster(cl)

# Measure end time and calculate duration
end_time <- Sys.time()
duration <- end_time - start_time
print(paste("Parallel processing completed in", round(duration, 2), "seconds"))



####################################################################
# OTHER TEST FUNCTION

# Set up parallel backend
cores <- detectCores()
cl <- makeCluster(cores[1] - 2)
registerDoParallel(cl)

# Measure start time
start_time <- Sys.time()

output_file <- "C:/Users/thoma/Desktop/STEP2 COPYAAAA/output.rds"

# Parallel loop
results <- foreach(i = enq) %dopar% {
  tryCatch(
    {
      d2p(libED = i, tripTable, indTable, cheminIn, output_file)
      NULL
    },
    error = function(e) {
      message(paste("Error processing", i, ":", conditionMessage(e)))
      NULL
    }
  )
}

# Stop parallel cluster
stopCluster(cl)

# Load the newly created presence table
newprez <- readRDS(output_file)

libED <- "MANCHESTER, 2022"  # Replace with a valid libED value from your data
d2p(libED, tripTable, indTable, cheminIn, output_file)















# ~ Compilation des présences ----

# ~~ Compilation d'une nouvelle table avec la BD_presence et sauvegarde ---
# THE FUNCTION DID NOT OUTPUT THE FILE THEREOFRE THE FOLLOWING CANNOUT WORK

# load table présence nouvellement créée
newprez <- readRDS(paste0(cheminOut, list.files(cheminOut)))

newprez <- newprez %>% 
  select(-nameFile) %>% 
  arrange(PAYS, LIB_ED) %>% 
  relocate(PAYS, ZONEGEO)

# check durée journée
newprez %>% 
  group_by(ID_IND) %>% 
  mutate(j = sum(DUREE)) %>% 
  filter(j!=1440)

skimr::skim(newprez)

# load BD_presence
prezTable <- readRDS(paste0(cheminIn, "BD_presence/BD_presence.RDS"))

# compilation
unique(prezTable$LIB_ED)
prezTable <- prezTable %>% 
  bind_rows(., newprez) %>% 
  arrange(PAYS, LIB_ED) %>% 
  relocate(PAYS, ZONEGEO)

length(unique(prezTable$ENQUETE))

# sauvegarde (hors git)
saveRDS(prezTable, paste0(cheminIn, "BD_presence/BD_presence.RDS"))

# suppression de multiTables
unlink(cheminOut, recursive = TRUE)


# ~~ OU Compilation de toutes les tables de présences et sauvegarde ---- 

# load tables présence
listdf <- list()
for (i in list.files(cheminOut)){
  prezTable <- readRDS(paste0(cheminOut, i))
  listdf[[i]] <- as.data.frame(prezTable)
  rm(prezTable)
}
# Compilation 
prezTable <- bind_rows(listdf, .id = "nameFile")

prezTable <- prezTable %>% 
  select(-nameFile) %>% 
  arrange(PAYS, LIB_ED) %>% 
  relocate(PAYS, ZONEGEO)

# sauvegarde (hors git)
saveRDS(prezTable, paste0(cheminIn, "BD_presence/BD_presence.RDS"))

# suppression de multiTables
unlink(cheminOut, recursive = TRUE)




















# ==== 2. BD_presence_utile ====

# dossier d'entrée (hors git)
cheminIn <- "../../../../00_BD_mobiliscope/"

# load BD_presence (hors git)
prezTable <- readRDS(paste0(cheminIn, "BD_presence/BD_presence.RDS"))

# Chargement de la fonction 
suppressWarnings(source("d2p_fct.R"))

# dossier de sortie (hors git)
cheminOut <- "../../../../00_BD_mobiliscope/BD_presence_utile/"


# sortir une table :
sort(unique(prezTable$ENQUETE))
createPrezLong(prezTable, cheminOut, enquete = "IDF2020")


# sortir plusieurs tables :
## calcul parallèle 
require(foreach)
require(doParallel)

## choix des enquêtes
enq <- unique(prezTable$ENQUETE)

## packages utilisés  
myPck <- as.vector(.packages())

## setup parallel backend to use many processors
cores <- detectCores()
cl <- makeCluster(cores[1]-2) # ! not overload your server
registerDoParallel(cl)

T1<-Sys.time()
foreach(i = enq, .packages = myPck) %dopar% {
  
  createPrezLong(prezTable, cheminOut, enquete = i) #calling function
  
}
## stop cluster
stopCluster(cl)

## process time = Tdiff
T2<-Sys.time()
(Tdiff= difftime(T2, T1)) # Time difference of 4.820819 mins pour 60 enquêtes

