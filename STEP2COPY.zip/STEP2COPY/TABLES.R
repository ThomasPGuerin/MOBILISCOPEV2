library(tidyverse)
library(dplyr)
library(lubridate)

df1 = readRDS("TRIPTABLEV1.RDS")
df2 = readRDS("PERSONTABLEV1.RDS")