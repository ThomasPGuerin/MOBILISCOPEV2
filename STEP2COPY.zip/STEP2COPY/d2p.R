# ================================================================================#
#                 Construction de la base de données des présences 
# 
#
# Description : 1. A partir de la BD_clean, création des tables de présence où
#               chaque ligne correspond à une présence géographique (secteur) et 
#               temporelle (une heure de la journée) et où chaque présence est 
#               caractérisée par le profil socio-démo de la personne enquêtée
#               2. création pour chaque ville d'une base "utile" pour p2m()
#               sans doublons, filtrée et au format long 
#       
#
# En entrée : BD_deplacement_clean et BD_personne_clean
# En sortie : BD_presence et BD_presence_utile_[ville]
#
# avril 2018 - AD
# rv en juillet 2020
# rv fev. 2021 pour inclure Canada
# rv juin 2021 intégration des villes sud-américaines
# oct. 2021 : correction des variables H4...H27 + calcul parallèle
# mars 2022 : réécriture complète de la fonction createPrez() 
#            (temps de computation 20 fois plus rapide)
#             et ajout de la fonction createPrezLong()
# sept 2022 : nom d'enquête en slug pour les sorties presence_utile  
#             + nouvelles règles doublons
# mai 2023 : ajout Idf 2020 dans createPrezLong()
#
# 
# 28 juin 2023 : dernière sortie des tables de présences (60 enquêtes)
# ================================================================================#


# Bibliothèque
library(tidyverse)
library(tidylog)
library(lubridate)


# ==== 1. BD_presence ====

# ~ Chargement des données de déplacement ---- 

# dossier d'entrée (hors git)
cheminIn <- "C:/Users/thoma/Desktop/STEP2COPY"

# Chargement de la BD_clean 
tripTable <- readRDS(paste0(cheminIn, "/FINALTRIPTABLEV3.RDS"))
indTable <- readRDS(paste0(cheminIn, "/FINALPERSONTABLEV3.RDS"))


# ~ Création des présences ---- 

# Chargement de la fonction 
suppressWarnings(source("d2p_fct.R"))

# dossier de sortie (hors git)
cheminOut <- "C:/Users/thoma/Desktop/STEP2COPY/multiTables/"
dir.create(cheminOut)




############################ PROBLEM #################################

# the problem is that the funciton expects columns in the data that don't exist
# I have added a few in the morepreocessing attached, but now there is a problem
# with the ZONE GEO column and the fact its a string or something
# to make the script work - essentially just play with the data preprocessing 
# script attached until we progressively find the differnt types of columns we
# need. It worked so far so we're not too far off.








# OPTION 1 (simple way that doesnt work):         ~~ sortir une table : ---- ERROR O_ZF NOT FOUND
unique(tripTable$LIB_ED)
d2p(libED = "MANCHESTER, 2022", tripTable, indTable, cheminIn, cheminOut)







# OPTION 2 (other way that doesnt work):        ~ OU sortir plusieurs tables : ----
## calcul parallèle 
require(foreach)
require(doParallel)

## choix des enquêtes
enq <- unique(tripTable$LIB_ED)

## packages utilisés  
myPck <- as.vector(.packages())

## setup parallel backend to use many processors
cores <- detectCores()
cl <- makeCluster(cores[1]-2) # ! not overload your server
registerDoParallel(cl)

T1<-Sys.time()
foreach(i = enq, .packages = myPck) %dopar% {
  
  d2p(libED = i, tripTable, indTable, cheminIn, cheminOut) #calling function
  
}
## stop cluster
stopCluster(cl)

## process time = Tdiff
T2<-Sys.time()
(Tdiff= difftime(T2, T1)) 

# Time difference of 17.68813 mins pour 60 enquêtes







###########################################################















# ~ Compilation des présences ----

# ~~ Compilation d'une nouvelle table avec la BD_presence et sauvegarde ---- 

# load table présence nouvellement créée
newprez <- readRDS(paste0(cheminOut, list.files(cheminOut)))

newprez <- newprez %>% 
  # select(-nameFile) %>% 
  arrange(PAYS, LIB_ED) %>% 
  relocate(PAYS, ZONEGEO)

# check durée journée
newprez %>% 
  group_by(ID_IND) %>% 
  mutate(j = sum(DUREE)) %>% 
  filter(j!=1440)

skimr::skim(newprez)

# load BD_presence
prezTable <- readRDS(paste0(cheminIn, "/multiTables/presence_MANCHESTER, 2022.RDS"))

# compilation
unique(prezTable$LIB_ED)
prezTable <- prezTable %>% 
  bind_rows(., newprez) %>% 
  arrange(PAYS, LIB_ED) %>% 
  relocate(PAYS, ZONEGEO)

length(unique(prezTable$ENQUETE))

# sauvegarde (hors git)
saveRDS(prezTable, paste0(cheminIn, "/BD_Presence.RDS"))

# suppression de multiTables
unlink(cheminOut, recursive = TRUE)


# ~~ OU Compilation de toutes les tables de présences et sauvegarde ---- 

# load tables présence
listdf <- list()
for (i in list.files(cheminOut)){
  prezTable <- readRDS(paste0(cheminOut, i))
  listdf[[i]] <- as.data.frame(prezTable)
  rm(prezTable)
}
# Compilation 
prezTable <- bind_rows(listdf, .id = "nameFile")

prezTable <- prezTable %>% 
  select(-nameFile) %>% 
  arrange(PAYS, LIB_ED) %>% 
  relocate(PAYS, ZONEGEO)

# sauvegarde (hors git)
saveRDS(prezTable, paste0(cheminIn, "BD_presence/BD_presence.RDS"))

# suppression de multiTables
unlink(cheminOut, recursive = TRUE)
















# ==== 2. BD_presence_utile ====

# dossier d'entrée (hors git)
cheminIn <- "C:/Users/thoma/Desktop/STEP2COPY"

# load BD_presence (hors git)
prezTable <- readRDS(paste0(cheminIn, "/BD_presence.RDS"))

# Chargement de la fonction 
suppressWarnings(source("d2p_fct.R"))

# dossier de sortie (hors git)
cheminOut <- "C:/Users/thoma/Desktop/STEP2COPY/BD_presence_utile/"


# sortir une table :
sort(unique(prezTable$ENQUETE))
createPrezLong(prezTable, cheminOut, enquete = "MANCHESTER", libED = "MANCHESTER") #CHANGED STUFF HERE


# sortir plusieurs tables :
## calcul parallèle 
require(foreach)
require(doParallel)

## choix des enquêtes
enq <- unique(prezTable$ENQUETE)

## packages utilisés  
myPck <- as.vector(.packages())

## setup parallel backend to use many processors
cores <- detectCores()
cl <- makeCluster(cores[1]-2) # ! not overload your server
registerDoParallel(cl)

T1<-Sys.time()
foreach(i = enq, .packages = myPck) %dopar% {
  
  createPrezLong(prezTable, cheminOut, enquete = i) #calling function
  
}
## stop cluster
stopCluster(cl)

## process time = Tdiff
T2<-Sys.time()
(Tdiff= difftime(T2, T1)) # Time difference of 4.820819 mins pour 60 enquêtes


