library(stringr)
library(tidyr)
library(dplyr)
library(readr)

data1 <- readRDS("C:/Users/thoma/Desktop/STEP 2 COPY/TRIPTABLEV1.RDS")

# save as csv
write_csv(data1, "C:/Users/thoma/Desktop/TRIPTABLEV1.csv")


data2 <- readRDS("C:/Users/thoma/Desktop/STEP 2 COPY/PERSONTABLEV1.RDS")

# save as csv
write_csv(data2, "C:/Users/thoma/Desktop/STEP 2 COPY/PERSONTABLEV1.csv")

