# the d2p script should not be changeded in the slightest, therefore my approach
# will be to progressively change the script to take add the right columns


library(tidyverse)
library(tidylog)
library(lubridate)

# Chargement de la BD_clean 
tripTable <- readRDS("TRIPTABLEV1.RDS")
indTable <- readRDS("PERSONTABLEV1.RDS")

tripTable$MODE_ADH[is.na(tripTable$MODE_ADH)] <- 0  # Default non-adherent


#Time Wrap-Around
# Adjust time wrap-around for H_START and H_END
tripTable <- tripTable %>%
  mutate(
    H_START = ifelse(H_START >= 24, H_START - 24, H_START),
    M_START = ifelse(H_START == 0 & M_START > 0, M_START - 60, M_START),
    M_END = ifelse(H_END == 0 & M_END > 0, M_END - 60, M_END)
  )

# adding pays and zonegeo columns
tripTable$PAYS <- 'UK'
tripTable$ZONEGEO <- 'Manchester'

indTable$PAYS <- 'UK'
indTable$ZONEGEO <- 'Manchester'

# Create O_COG and D_COG columns in tripTable
# Create O_COG, D_COG, O_ZF, and D_ZF columns in tripTable
unique_sec <- unique(c(tripTable$O_SEC, tripTable$D_SEC))
sec_lookup <- data.frame(SEC = unique_sec, COG = seq_along(unique_sec), ZF = seq_along(unique_sec))
# 
# tripTable <- tripTable %>%
#   left_join(sec_lookup, by = c("O_SEC" = "SEC")) %>%
#   rename(O_COG = COG, O_ZF = ZF) %>%
#   left_join(sec_lookup, by = c("D_SEC" = "SEC")) %>%
#  rename(D_COG = COG, D_ZF = ZF)
# 

# Create O_COG, D_COG, O_ZF, and D_ZF columns in tripTable
unique_sec <- unique(c(tripTable$O_SEC, tripTable$D_SEC))
sec_lookup <- data.frame(SEC = unique_sec, COG = seq_along(unique_sec), ZF = seq_along(unique_sec))

tripTable <- tripTable %>%
  left_join(sec_lookup, by = c("O_SEC" = "SEC")) %>%
  rename(O_COG = COG, O_ZF = ZF) %>%
  left_join(sec_lookup, by = c("D_SEC" = "SEC")) %>%
  rename(D_COG = COG, D_ZF = ZF) %>%
  mutate(
    PAYS = as.character(PAYS),
    ZONEGEO = as.character(ZONEGEO)
  )

# select O_SEC and O_COG from triptable and create new df2 wiht them
df2 <- tripTable %>%
  select(O_SEC, O_COG) %>%
  distinct()

# create csv with df2
write.csv(df2, "wardcodesandindex.csv")

# CREATE ZF_RES with the same encoding as above
# Create RES_ZF column in indTable using the updated sec_lookup
indTable <- indTable %>%
  left_join(sec_lookup, by = c("RES_SEC" = "SEC")) %>%
  rename(RES_COG = COG, RES_ZF = ZF) %>%
  mutate(
    PAYS = as.character(PAYS),
    ZONEGEO = as.character(ZONEGEO)
  )

indTable$ID_SEC <- indTable$RES_SEC

indTable$ZONAGE_SEC <- indTable$ID_SEC

indTable <- indTable %>%
  left_join(sec_lookup, by = c("ZONAGE_SEC" = "SEC")) %>%
  rename(ZONAGE_COG = COG, ZONAGE_ZF = ZF) %>%
  mutate(
    PAYS = as.character(PAYS),
    ZONEGEO = as.character(ZONEGEO)
  )



#change ZONEGEO in triptable and indtable to 99
#tripTable$ZONEGEO <- 99
#indTable$ZONEGEO <- 99


# change O_ZF and D_ZF to as numiric
# tripTable$O_ZF <- as.numeric(tripTable$O_ZF)
# tripTable$D_ZF <- as.numeric(tripTable$D_ZF)
# 
# 
# tripTable$D_COG <- as.numeric(tripTable$D_COG)
# tripTable$O_COG <- as.numeric(tripTable$O_COG)
# 
# tripTable$O_PURPOSE <- as.numeric(tripTable$O_PURPOSE)
# tripTable$D_PURPOSE <- as.numeric(tripTable$D_PURPOSE)


# # OR AS CHARACTER - not working either DONT RUN
# tripTable$O_ZF <- as.character(tripTable$O_ZF)
# tripTable$D_ZF <- as.character(tripTable$D_ZF)
# 
# 
# tripTable$D_COG <- as.character(tripTable$D_COG)
# tripTable$O_COG <- as.character(tripTable$O_COG)
# 
# tripTable$O_PURPOSE <- as.character(tripTable$O_PURPOSE)
# tripTable$D_PURPOSE <- as.character(tripTable$D_PURPOSE)

# Creat a RES_ZF column for error at line 155




#Save the new tripTable and indTable as RDS
saveRDS(tripTable, "TRIPTABLEV12.RDS")
saveRDS(indTable, "PERSONTABLEV12.RDS")



DF8 = readRDS("C:/Users/thoma/Desktop/STEP3COPY/BD_presence_utile/presence_manchester.RDS")

# left joining sec lookup with code_sec in df8
DF9 <- DF8 %>%
  left_join(sec_lookup, by = c("CODE_SEC" = "SEC"))
  # rename(COG = COG, ZF = ZF) %>%
  # mutate(
  #   PAYS = as.character(PAYS),
  #   ZONEGEO = as.character(ZONEGEO)
  # )


DF9 <- DF9 %>% 
  select(-CODE_SEC, -ZF)

DF9 <- DF9 %>%
  rename(CODE_SEC = COG)

# left joining sec lookup with code_sec in df8
DF10 <- DF9 %>%
  left_join(sec_lookup, by = c("RES_SEC" = "SEC"))
# rename(COG = COG, ZF = ZF) %>%
# mutate(
#   PAYS = as.character(PAYS),
#   ZONEGEO = as.character(ZONEGEO)
# )


DF10 <- DF10 %>% 
  select(-RES_SEC, -ZF)

DF10 <- DF10%>%
  rename(RES_SEC = COG)


saveRDS(DF10, "C:/Users/thoma/Desktop/STEP3COPY/BD_presence_utile/presence_manchester.RDS")
