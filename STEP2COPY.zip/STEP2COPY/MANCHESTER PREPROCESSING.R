library(tidyverse)
library(tidylog)
library(lubridate)
library(dplyr)

# loading the data
Household1 <- read_csv("C:/Users/thoma/Desktop/HouseholdPerson 2017-22 - Mobiliscope (FINAL) - values.csv")

Household2 <- read_csv("C:/Users/thoma/Desktop/HouseholdPerson 2017-22 - Mobiliscope (FINAL).csv")

# merge on 'UniqueID', 'HouseholdIDNumber', 'PersonNumber', 'Home_LSOA_Code', 'Home_LSOA_Name'
merged_household <- merge(Household1, Household2, by = c('UniqueID', 'HouseholdIDNumber', 'PersonNumber', 'Home_LSOA_Code', 'Home_LSOA_Name'))


# Creating a dictionary 

# Function to convert grouped data to single values if possible
convert_to_single_value_list <- function(df, group_column, value_column) {
  mappings <- df %>%
    group_by(!!sym(group_column)) %>%
    summarise(values = list(unique(!!sym(value_column))), .groups = 'drop')
  
  # Convert the list of values to a single value if there is only one unique value
  mappings$values <- lapply(mappings$values, function(x) {
    if (length(x) == 1) {
      return(x[1])
    } else {
      return(x)
    }
  })
  
  # Convert to a named list for dictionary-like usage
  setNames(mappings$values, mappings[[group_column]])
}

# Applying the function to multiple columns
columns <- c('HomeDistrictCode', 'Gender', 'ageband', 'WorkStatusID', 'DisabilityLimited', 'EthnicGroup')
dicts <- list()

for (column in columns) {
  column_y <- paste0(column, '.y')
  column_x <- paste0(column, '.x')
  dicts[[column]] <- convert_to_single_value_list(merged_household, column_y, column_x)
}
